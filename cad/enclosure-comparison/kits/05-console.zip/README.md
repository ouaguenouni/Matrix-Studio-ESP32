# 05-console — enclosure prototype kit

Units: mm. Physical fit remains unverified. Read [PRINT-GUIDE.md](PRINT-GUIDE.md) before printing.

Case: 202 × 122 × 108.5 mm; acrylic 164 × 84 × 1.0 mm.

[Front/rear preview](05-console/preview.png) · [Exploded view](05-console/exploded.png) · [Editable model](05-console/model.scad)

Keep folder structure intact so the model finds `../family.scad`. Print individual STLs only.

| Part | Quantity |
| --- | ---: |
| bezel.stl | 1 |
| body.stl | 1 |
| lid.stl | 1 |
| keeper.stl | 1 |
| bridge.stl | 2 |
| carrier.stl | 1 |
| rail.stl | 2 |
| spacer.stl | 4 |
| ports.stl | 1 |
| cassette.stl | 1 |
| feet.stl | 2 |
| coupon.stl | 1 |
| ports_usb_c.stl | 0 |

`ports_usb_c` is an optional replacement for `ports`. Test the coupon first.
