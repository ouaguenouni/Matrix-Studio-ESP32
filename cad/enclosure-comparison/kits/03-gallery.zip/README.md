# 03-gallery — enclosure prototype kit

Units: mm. Physical fit remains unverified. Read [PRINT-GUIDE.md](PRINT-GUIDE.md) before printing.

Case: 206 × 156 × 96.5 mm; acrylic 180 × 130 × 1.0 mm.

[Front/rear preview](03-gallery/preview.png) · [Exploded view](03-gallery/exploded.png) · [Editable model](03-gallery/model.scad)

Keep folder structure intact so the model finds `../family.scad`. Print individual STLs only.

| Part | Quantity |
| --- | ---: |
| bezel.stl | 1 |
| body.stl | 1 |
| lid.stl | 1 |
| keeper.stl | 1 |
| bridge.stl | 2 |
| carrier.stl | 1 |
| rail.stl | 2 |
| spacer.stl | 4 |
| ports.stl | 1 |
| cassette.stl | 1 |
| feet.stl | 2 |
| coupon.stl | 1 |
| ports_usb_c.stl | 0 |

`ports_usb_c` is an optional replacement for `ports`. Test the coupon first.
